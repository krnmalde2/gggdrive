class Creds():
    # ENTER Your bot Token Here
    TG_TOKEN = "12345678:ABCDEFGHIJKo5DAHsd-Wy-ZMtV4"
